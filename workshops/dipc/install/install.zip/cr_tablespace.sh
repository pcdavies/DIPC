#!/bin/bash

sqlplus system/Alpha2018_@pdb1 << EOF

create tablespace alpha_archive
nologging
datafile '/u02/app/oracle/oradata/ORCL/PDB1/alpha_archive.dbf'
size 10m autoextend on
next 10m maxsize unlimited
extent management local;

create user alpha_archive identified by Alpha2018_ default tablespace alpha_archive;

grant dba to alpha_archive;

EOF

impdp alpha_archive/Alpha2018_@pdb1 directory=oracle dumpfile=alpha.dmp remap_schema=alpha:alpha_archive remap_tablespace=users:alpha_archive
